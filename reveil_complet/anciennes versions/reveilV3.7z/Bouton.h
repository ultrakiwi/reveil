#ifndef BOUTON_H
#define BOUTON_H

#include <Arduino.h>

/// Classe tr�s simple g�rant un bouton poussoir connect� sur une entr�e num�rique.
class Bouton
{
  public:
    Bouton(const int & pinBP, const bool & etatRepos = LOW);
    ~Bouton(void) {};

    void listen(void) {
      m_etatPrecedent = m_etatActuel;
      m_etatActuel = digitalRead(m_pinBP);
    }

    bool pressed(void) const {
      return m_etatActuel == m_niveauAppui;
    }
    bool released(void) const {
      return !pressed();
    }

    bool onPress(void) const {
      return (pressed() && (m_etatPrecedent != m_niveauAppui));
    }

  private:
    const int m_pinBP;		///< broche sur laquelle es tconnect�e le bouton
    bool m_niveauAppui;		///< �tat actif du bouton (ie quand il est enfonc�)
    bool m_etatActuel;		///< dernier �tat lu du bouton
    bool m_etatPrecedent;	///< �tat du bouton lors de la pr�c�dente lecture
};

Bouton::Bouton(const int & pinBP,
               const bool & niveauAppui)
  :
  m_pinBP(pinBP),
  m_niveauAppui(niveauAppui),
  m_etatActuel(!m_niveauAppui),
  m_etatPrecedent(m_etatActuel)
{
  pinMode(m_pinBP, INPUT);
}

#endif //BOUTON_H
